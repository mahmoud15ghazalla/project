export default function Routing() {
  return (
    <>
      <h1 className="text-center">Routing page</h1>
    </>
  );
}
